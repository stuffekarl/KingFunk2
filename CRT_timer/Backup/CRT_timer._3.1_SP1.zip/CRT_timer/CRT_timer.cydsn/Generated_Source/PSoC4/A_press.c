/*******************************************************************************
* File Name: A_press.c  
* Version 2.10
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "A_press.h"

#define SetP4PinDriveMode(shift, mode)  \
    do { \
        A_press_PC =   (A_press_PC & \
                                (uint32)(~(uint32)(A_press_DRIVE_MODE_IND_MASK << (A_press_DRIVE_MODE_BITS * (shift))))) | \
                                (uint32)((uint32)(mode) << (A_press_DRIVE_MODE_BITS * (shift))); \
    } while (0)


/*******************************************************************************
* Function Name: A_press_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None 
*  
*******************************************************************************/
void A_press_Write(uint8 value) 
{
    uint8 drVal = (uint8)(A_press_DR & (uint8)(~A_press_MASK));
    drVal = (drVal | ((uint8)(value << A_press_SHIFT) & A_press_MASK));
    A_press_DR = (uint32)drVal;
}


/*******************************************************************************
* Function Name: A_press_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to one of the following drive modes.
*
*  A_press_DM_STRONG     Strong Drive 
*  A_press_DM_OD_HI      Open Drain, Drives High 
*  A_press_DM_OD_LO      Open Drain, Drives Low 
*  A_press_DM_RES_UP     Resistive Pull Up 
*  A_press_DM_RES_DWN    Resistive Pull Down 
*  A_press_DM_RES_UPDWN  Resistive Pull Up/Down 
*  A_press_DM_DIG_HIZ    High Impedance Digital 
*  A_press_DM_ALG_HIZ    High Impedance Analog 
*
* Return: 
*  None
*
*******************************************************************************/
void A_press_SetDriveMode(uint8 mode) 
{
	SetP4PinDriveMode(A_press__0__SHIFT, mode);
}


/*******************************************************************************
* Function Name: A_press_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro A_press_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 A_press_Read(void) 
{
    return (uint8)((A_press_PS & A_press_MASK) >> A_press_SHIFT);
}


/*******************************************************************************
* Function Name: A_press_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 A_press_ReadDataReg(void) 
{
    return (uint8)((A_press_DR & A_press_MASK) >> A_press_SHIFT);
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(A_press_INTSTAT) 

    /*******************************************************************************
    * Function Name: A_press_ClearInterrupt
    ********************************************************************************
    *
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 A_press_ClearInterrupt(void) 
    {
		uint8 maskedStatus = (uint8)(A_press_INTSTAT & A_press_MASK);
		A_press_INTSTAT = maskedStatus;
        return maskedStatus >> A_press_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 


/* [] END OF FILE */
