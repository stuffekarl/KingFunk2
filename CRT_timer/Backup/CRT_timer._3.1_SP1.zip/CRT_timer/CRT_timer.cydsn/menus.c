/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

/* [] END OF FILE */

#include "menus.h"


/* Main menu:
|Press SLCT 2 run|
|N=x,avg=16.33 ms|

|      Blip!     |
|       {}       |
*/

/* Calibration menu:
|Press SLCT to   |
|calibrate sensor|

|Put sensor near |
|Fox & press SLCT|

|Calibrating...  |
|                |

|Testing...      |
|                |

|Calibration...  |
|COMPLETE!       |
OR
|Calibration...  |
|FAILURE!        |
*/


/*
|                |
|                |
*/