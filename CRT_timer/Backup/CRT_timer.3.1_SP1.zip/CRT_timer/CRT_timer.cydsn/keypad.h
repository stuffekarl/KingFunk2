/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

//Variables
typedef enum {UNPRESSED, SELECT, LEFT, DOWN, UP, RIGHT } BTN_states;

//Protoypes
BTN_states getButton();

/* [] END OF FILE */